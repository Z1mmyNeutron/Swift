import UIKit

struct Triangle{
	var height = 10.0
	var width = 10.0
	
	func printArea(){
		print("the area of this \(self) is \(0.5 * self.height * self.width)")
	}
	
	mutating func changeHeight(to newHeight: Double){
		self.height = newHeight
	}
	mutating func changeWidth(to newWidth: Double){
		self.width = newWidth
	}
}
var myFirstTriangle = Triangle();
myFirstTriangle.printArea()



struct Circle{
	var origin: (Int, Int)
	var radius: Double
	
	init(startingAt origin: (Int, Int), radius: Double){
		self.origin = origin
		self.radius = radius
	}
	
	func printArea(){
		print("The area of this \(self) is \(Double.pi * radius * radius) units")
	}
	
	mutating func moveOrigin(to newPoint: (Int, Int)){
		self.origin = newPoint
	}
}
var myFirstCirc = Circle( startingAt:(0,0), radius: 5.6);
myFirstCirc.moveOrigin(to: (5,7))
