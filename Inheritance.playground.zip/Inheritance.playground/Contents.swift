import UIKit




class Shape: CustomStringConvertible{
	
	var name: String
	var numPoints: Int
	var numSides: Int
	var description: String {
		return "A \(self.name) has \(self.numPoints) points"
	}
	init(shape name: String, number points: Int, sides: Int ){
		self.name = name
		self.numPoints = points
		self.numSides = sides
	}
	
	func change(number points: Int){
		self.numPoints = points
	}
	
	func change(shape name: String){
		self.name = name
	}
	
}


class Circle: Shape{
	
	var radius: Double
	var circumference: Double{
		return (2.0 * Double.pi * self.radius)
	}
	var area: Double{
		return (Double.pi * self.radius * self.radius)
	}
	
	override var description: String{
		return super.description + "\nA Circle has \nradius: \(self.radius) \narea: \(self.area) \ncircumference: \(self.circumference)\n"
	}
	init(radius: Double){
		self.radius = radius
		super.init(shape: "Circle", number: 0, sides: 0)
	}
	
	
}

class Rectangle: Shape{
	
	var side1: Double
	var side2: Double
	
	var perimeter: Double{
		return (self.side1 * 2 + self.side2 * 2)
	}
	var area: Double{
		return (self.side1 * self.side2)
	}
	
	override var description: String{
		return super.description + "\nA Rectangle has \nside 1: \(self.side1) units \nside 2: \(self.side2) \narea: \(self.area) \nperimeter: \(self.perimeter)\n"
	}
	
	init(side1: Double, side2: Double){
		self.side1 = side1
		self.side2 = side2
		super.init(shape: "Rectangle", number: 4, sides: 4)
	}
	
	
}



var myCircle = Circle(radius: 5)
//print(myCircle)

var myRect = Rectangle(side1: 5.0, side2: 5.1)
//print(myRect)


func compareShapes(one: Shape, two: Shape)-> Int?{
	
	switch (one.numSides - two.numSides){
	case ..<0: return -1
	case 0: return 0
	case 0...: return 1
	default: return nil
	}
	
}

print(compareShapes(one: myRect, two: myCircle)!)

var shapeArr: [Shape] = [myCircle, myRect]
for each in shapeArr{

	if each is Circle{
		print(" Area: \((each as! Circle).area)")
	}
	if each is Rectangle{
		print(" Area: \((each as! Rectangle).area)")
	}
	print("Circumference: \((each as? Circle)?.circumference)")
	print("Perimeter: \((each as? Rectangle)?.perimeter)")

}
