import UIKit

class simpleClass{
	
	var desc: String = ""
	var name: String = ""
	
	func printDescription() -> String{
		return "\(name): \(desc)"
	}
}

class complexClass: simpleClass{
	
	var age: Int = 0
	
	override func printDescription() -> String{
		return "\(self.name): \(self.desc) \n age: \(self.age)"
	}
	
}

class Shape{
	
	var name: String
	var numPoints: Int
	
	init(shape name: String, number points: Int ){
		self.name = name
		self.numPoints = points
	}
	
	func change(number points: Int){
		self.numPoints = points
	}
	
	func change(shape name: String){
		self.name = name
	}
	
	func printDescription()-> String{
		return "A \(self.name) has \(self.numPoints) points"
	}
	
	
}

var point = Shape(shape: "Point", number: 1);
var line = Shape(shape: "Line", number: 2);
print(line.printDescription())

var line2 = line
print(line2.printDescription())
line.change(shape: "triangle")
line.change(number: 3)
print(line2.printDescription())
