import UIKit
///**********Defining an Enum********
//enum membershipLevel{
//	case freemiumMember
//	case baseMember
//	case plusMember
//	case premiumMember
//}
/////********************
//
/////Assigning values to enums
//var myMembership = membershipLevel.freemiumMember
//myMembership = .plusMember
////
///////**************Switching on Enum values******************
//////Notice that the switch is "exhaustive" without needing a default because we have
//switch myMembership{
//case .freemiumMember: print("Upgrade your membership for more features...")
//case .baseMember: print(" You now have access to the basic Membership features!")
//case .plusMember: print("Now you can view some of app's secret features!")
//case .premiumMember: print("Now you can do anything you want!")
//}
///*************

///**********Simple Enumerations with Raw Values**********
enum logInStatus: Int{
	case guest
	case member
	case admin
	case NOT
}


print("Raw value for .guest is \(logInStatus.guest.rawValue)")
print("Raw value for .member is \(logInStatus.member.rawValue)")
print("Raw value for .admin is \(logInStatus.admin.rawValue)")

//Creating an enum instance from a raw value

var currentStatus = logInStatus(rawValue: 87)
//print("You are currently logged in as 	a \(currentStatus ?? logInStatus.NOT)")
/////////**********
////
////
////////**************Manually assigning Raw Values**************/
//enum letters: Character{
//	case A = "A"
//	case B = "B"
//	case C = "C"
//}
//print("Raw value for a is \(letters.A.rawValue)")
//print("Raw value for b is \(letters.B.rawValue)")
//print("Raw value for c is \(letters.C.rawValue)")
//
//
/////**********Looping through an Enum**********
//enum workWeek: String, CaseIterable{
//	case monday
//	case tuesday
//	case wedsday
//	case thursday
//	case friday
//}
//var count = 0
//for eachDay in workWeek.allCases{
//	count += 1
//	print("Day \(count) of the work week is \(eachDay)")
//}
////
/////**************Enums as First Class Data Types**************
enum Month: Int, CaseIterable{
	case January
	case February
	case March
	case April
	case May
	case June
	case July
	case August
	case September
	case October
	case November
	case December

	//Default initializer to create an enum starting in January
	init(starting month: Int){
		self = Month(rawValue: month) ?? .January
	}
	func numDays(_ leapYear: Bool) -> Int{
		switch self{
		case .September, .April, .June, .November: return 30
		case .February: return (leapYear ? 29 : 28)
		default: return 31
		}
	}
	func currentMonth(){
		print("It's \(self) right now...")
		
	}
	mutating func nextMonth(){
		let nextMonth = (self.rawValue + 1) % Month.allCases.count //makes it circular

		self = Month(rawValue: nextMonth)!
		print("Month updated to \(self)")
	}
}
//
var Winter = [ Month.December, .January, .February] //Compiler infers the Array type from the first element
for month in Winter{
	print("\(month) has \(month.numDays(true)) days")
}
////
var hottest = Month.August
hottest.nextMonth()

//var coldest = Month.December
//coldest.nextMonth()
/////***********************************************
//
//////**********Intro to Value Types**********/
////
var first = Month.January
var coldest = first //coldest is a distinct copy of first
coldest.nextMonth()
first.currentMonth()//notice how the change to Coldest does not affect first
//
//
/////******************
//
/////******************Associated Types**********
////Month with associated values
//
enum timeUnits{

	case second(howMany: Int)
	case minute(howMany: Int)
	case hour(howMany: Int)
	case day(howMany: Int)
	case Instantaneous

	func numberOfSeconds()-> Int{
		switch self{
		case let .second(howMany: numberOfSeconds): return numberOfSeconds
		case let .minute(howMany: numberOfMinutes): return numberOfMinutes * 60
		case let .hour(howMany: numberOfHours) : return numberOfHours * 3600
		case let .day(howMany: numberOfDays) : return numberOfDays * 3600 * 24
		case .Instantaneous: return 0
		}

	}

	func numberOfMinutes() -> Double{
		switch self{
			case let .second(howMany: numberOfSeconds): return Double(numberOfSeconds) / Double(60)
			case let .minute(howMany: numberOfMinutes): return Double(numberOfMinutes)
			case let .hour(howMany: numberOfHours) : return Double(numberOfHours) * Double(60)
			case let .day(howMany: numberOfDays) : return Double(numberOfDays) * 60 * 24
			case .Instantaneous: return 0
			}

	}




}
	var time = timeUnits.hour(howMany: 5)
print(time.numberOfMinutes())

var time2 = timeUnits.hour(howMany: 100)
time2.numberOfSeconds()
